import { randomBytes } from "node:crypto";
import type { Dirent } from "node:fs";
import { chmod, mkdir, readdir, readFile, rename, rm, stat, writeFile } from "node:fs/promises";
import { dirname, isAbsolute, join, relative, resolve, sep } from "node:path";
import { type ContentHash, contentHashOf } from "../content-identity/content-hash.ts";
import { StaleExpectedHash } from "./exact-edit.ts";
import { type FileTreeEntry, type FileTreePort, WorkspaceEntryAlreadyExists, WorkspaceEntryDoesNotExist } from "./file-tree-port.ts";
import type { WorkspaceEntry, WorkspacePort } from "./port.ts";

const DEFAULT_NEW_FILE_MODE = 0o644;
const PERMISSION_BITS_MASK = 0o777;

/** Raised when a path would resolve outside the workspace's own root directory. */
export class PathEscapesWorkspaceRoot extends Error {
	constructor(
		readonly path: string,
		readonly root: string,
	) {
		super(`path "${path}" escapes workspace root "${root}"`);
		this.name = "PathEscapesWorkspaceRoot";
	}
}

function isEnoent(error: unknown): boolean {
	return typeof error === "object" && error !== null && "code" in error && (error as { code?: unknown }).code === "ENOENT";
}

/**
 * LocalFilesystemWorkspace -- a WorkspacePort backed by real files under one
 * root directory, with expected-hash-guarded atomic writes.
 *
 * Writes go through a same-directory temp file, chmod'd to the target's
 * existing mode before the rename (temp files default to a more
 * restrictive mode, which a naive rename would otherwise leave in place).
 */
export class LocalFilesystemWorkspace implements WorkspacePort, FileTreePort {
	private readonly root: string;

	constructor(root: string) {
		this.root = resolve(root);
	}

	resolvePath(path: string): string {
		const absolute = resolve(this.root, path);
		// node:path's relative(), not string-prefix concatenation: `this.root + sep` breaks for
		// the filesystem root itself ("/" + "/" = "//", which no real absolute path starts
		// with -- root="/" is a real, legitimate case: a path with no enclosing project root
		// falls back to it, per pi-lector's workspaceForPath, and every such read was rejected
		// as "escaping" a root it did not actually escape at all).
		const relativeToRoot = relative(this.root, absolute);
		if (relativeToRoot === ".." || relativeToRoot.startsWith(`..${sep}`) || isAbsolute(relativeToRoot)) {
			throw new PathEscapesWorkspaceRoot(path, this.root);
		}
		return absolute;
	}

	async readEntry(path: string): Promise<WorkspaceEntry> {
		const absolute = this.resolvePath(path);
		try {
			const content = await readFile(absolute, "utf-8");
			return { exists: true, content };
		} catch (error) {
			if (isEnoent(error)) return { exists: false };
			throw error;
		}
	}

	async writeEntry(path: string, expectedHash: ContentHash | null, content: string): Promise<{ previousHash: ContentHash | null; newHash: ContentHash }> {
		const absolute = this.resolvePath(path);

		let previousHash: ContentHash | null = null;
		let previousMode: number | undefined;
		try {
			const [existingContent, stats] = await Promise.all([readFile(absolute, "utf-8"), stat(absolute)]);
			previousHash = contentHashOf(existingContent);
			previousMode = stats.mode & PERMISSION_BITS_MASK;
		} catch (error) {
			if (!isEnoent(error)) throw error;
		}

		if (previousHash !== expectedHash) {
			throw new StaleExpectedHash(path, expectedHash, previousHash);
		}

		await mkdir(dirname(absolute), { recursive: true });
		const tempPath = join(dirname(absolute), `.lector-${randomBytes(8).toString("hex")}.tmp`);
		try {
			await writeFile(tempPath, content, "utf-8");
			await chmod(tempPath, previousMode ?? DEFAULT_NEW_FILE_MODE);
			await rename(tempPath, absolute);
		} catch (error) {
			await rm(tempPath, { force: true });
			throw error;
		}

		return { previousHash, newHash: contentHashOf(content) };
	}

	async deleteEntry(path: string, expectedHash: ContentHash): Promise<{ previousHash: ContentHash }> {
		const absolute = this.resolvePath(path);

		let previousHash: ContentHash | null = null;
		try {
			const existingContent = await readFile(absolute, "utf-8");
			previousHash = contentHashOf(existingContent);
		} catch (error) {
			if (!isEnoent(error)) throw error;
		}

		if (previousHash !== expectedHash) {
			throw new StaleExpectedHash(path, expectedHash, previousHash);
		}

		await rm(absolute, { force: true });
		return { previousHash };
	}

	async listDirectory(path: string): Promise<FileTreeEntry[]> {
		const absolute = this.resolvePath(path);
		const dirents = await readdir(absolute, { withFileTypes: true });
		return Promise.all(dirents.map(async (dirent) => ({ name: dirent.name, kind: await this.entryKind(absolute, dirent) })));
	}

	/**
	 * A bun-managed node_modules layout symlinks scoped packages to their real store location --
	 * the raw dirent type (isDirectory()/isSymbolicLink()) only describes the link itself, never
	 * what it points to. Since FileTreeEntry.kind's own contract is "Enter descends vs. opens"
	 * (see file-tree-port.ts), a symlink is resolved to its real target's kind here so navigation
	 * is correct; a broken symlink (target no longer exists) falls back to "symlink", since it is
	 * genuinely neither a real directory nor a real file to open.
	 */
	private async entryKind(parentAbsolute: string, dirent: Dirent): Promise<FileTreeEntry["kind"]> {
		if (dirent.isDirectory()) return "directory";
		if (!dirent.isSymbolicLink()) return "file";
		try {
			const resolved = await stat(join(parentAbsolute, dirent.name));
			return resolved.isDirectory() ? "directory" : "file";
		} catch {
			return "symlink";
		}
	}

	async createDirectory(path: string): Promise<void> {
		const absolute = this.resolvePath(path);
		await mkdir(absolute, { recursive: true });
	}

	async renamePath(oldPath: string, newPath: string): Promise<void> {
		const absoluteOld = this.resolvePath(oldPath);
		const absoluteNew = this.resolvePath(newPath);
		if (!(await this.pathExists(absoluteOld))) throw new WorkspaceEntryDoesNotExist(oldPath);
		if (await this.pathExists(absoluteNew)) throw new WorkspaceEntryAlreadyExists(newPath);
		await mkdir(dirname(absoluteNew), { recursive: true });
		await rename(absoluteOld, absoluteNew);
	}

	async deleteDirectory(path: string): Promise<void> {
		const absolute = this.resolvePath(path);
		await rm(absolute, { recursive: true, force: true });
	}

	private async pathExists(absolute: string): Promise<boolean> {
		try {
			await stat(absolute);
			return true;
		} catch (error) {
			if (isEnoent(error)) return false;
			throw error;
		}
	}
}
